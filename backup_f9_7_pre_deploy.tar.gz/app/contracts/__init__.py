# app.contracts package marker
# Keep this file minimal to avoid importing runtime dependencies
