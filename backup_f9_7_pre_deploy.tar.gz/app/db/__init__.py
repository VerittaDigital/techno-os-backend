# Database initialization and session management
