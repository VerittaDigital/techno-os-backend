# Offline tools for audit analysis and reconciliation
