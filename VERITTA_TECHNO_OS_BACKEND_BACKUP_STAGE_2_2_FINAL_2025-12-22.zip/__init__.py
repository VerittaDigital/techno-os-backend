# Package marker for the app package.
# Note: Do NOT import from .main here; it causes circular imports
# and pulls in FastAPI for contracts. Tests import app directly from main.py.
