"""Executor implementations for agentic pipeline."""
